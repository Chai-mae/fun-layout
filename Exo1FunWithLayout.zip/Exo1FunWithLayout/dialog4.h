#ifndef DIALOG4_H
#define DIALOG4_H

#include <QWidget>
#include<QPushButton>
#include<QLCDNumber>
#include <QVector>
#include <QGridLayout>

class dialog4 : public QWidget
{
    Q_OBJECT
public:
    explicit dialog4(QWidget *parent = nullptr);
protected:
    QLCDNumber *lcdnumber;
    QVector<QPushButton*> numbers;  //Vector for the numbers
    QPushButton *enterbutton;
    QGridLayout *gridlayout;

protected:
    void createWidgets();
    void placeWidgets();


};

#endif // DIALOG4_H
