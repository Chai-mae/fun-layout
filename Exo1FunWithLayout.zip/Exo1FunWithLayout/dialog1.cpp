#include "dialog1.h"
#include<QHBoxLayout>


Dialog1::Dialog1(QWidget *parent) : QWidget(parent)
{
    createWidget();
    placeWidget();


}
void Dialog1::createWidget(){


label = new QLabel("Name:");

 edit = new QLineEdit;
 button= new QPushButton("Search");
    this->setWindowTitle("HBoxLayout test");
}
void Dialog1::placeWidget(){
    QHBoxLayout* mainlayout = new QHBoxLayout;
    this->setLayout(mainlayout);
    mainlayout->addWidget(label);
    mainlayout->addWidget(edit);
    mainlayout->addWidget(button);
}
