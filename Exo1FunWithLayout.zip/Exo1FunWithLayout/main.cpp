#include <QApplication>

#include<dialog1.h>
#include<QWidget>
#include<dialog2.h>
#include<dialog3.h>
#include<dialog4.h>

int main(int argc, char* argv[])
{
 QApplication app(argc, argv);


// Dialog1 * d= new Dialog1;
// Dialog2 * d= new Dialog2;
// dialog3 * d= new dialog3;

dialog4 * d= new dialog4;


  d->show();
return app.exec();
}
