#include "dialog3.h"
#include<QFormLayout>
#include<QBoxLayout>

dialog3::dialog3(QWidget *parent) : QWidget(parent)
{
    createWidgets();
    placeWidgets();

}
void dialog3::createWidgets(){
    name = new QLineEdit;
    company= new QLineEdit;
    title= new QLineEdit;
    phone= new QLineEdit;
    email= new QLineEdit;
    repro = new QComboBox;
    info= new QTextEdit;
    buttonbox = new QDialogButtonBox;

}
void dialog3::placeWidgets(){
    auto *formlayout =new QFormLayout;
    auto *mainlayout = new QVBoxLayout ;
    repro->addItem(tr("Always"));
    repro->addItem(tr("Sometimes"));
    repro->addItem(tr("Rarely"));
    formlayout->addRow("Name:", name);
    formlayout->addRow("Company:" , company);
    formlayout->addRow("Phone:", phone);
    formlayout->addRow("Email:", email);
    formlayout->addRow("Problem Title:", title);
    formlayout->addRow("Summary Information:", info);
    formlayout->addRow("Reproducibility:", repro);
    buttonbox->addButton(tr("Submit Bug Report"),QDialogButtonBox::AcceptRole);
    buttonbox->addButton(tr("Don't Submit"), QDialogButtonBox::RejectRole);
    buttonbox->addButton(QDialogButtonBox::Reset);

    mainlayout->addLayout(formlayout);
    mainlayout->addWidget(buttonbox);
    setLayout(mainlayout);

    setWindowTitle("Report Bug");




}
