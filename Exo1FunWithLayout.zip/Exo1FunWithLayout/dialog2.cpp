#include "dialog2.h"
#include <QHBoxLayout>
#include <QVBoxLayout>

Dialog2::Dialog2(QWidget *parent) : QWidget(parent)
{
    createWidgets();
    placeWidgets();
    makeconnexion();

}
void Dialog2::createWidgets(){
    l1 = new QLabel("Name:");
    edit = new QLineEdit;
    c1 = new QCheckBox("Match Case");
    c2 = new QCheckBox("Search Backward");
    b1 = new QPushButton("Search");
    b2 = new QPushButton("Close");
    this->setWindowTitle("Nested Layout Test");


}
void Dialog2::placeWidgets(){
    auto topleftlayout= new QHBoxLayout;
    auto leftlayout = new QVBoxLayout;
    auto rightlayout = new QVBoxLayout;
    auto mainlayout = new QHBoxLayout;
    this->setLayout(mainlayout);
    topleftlayout->addWidget(l1);
    topleftlayout->addWidget(edit);
    leftlayout->addLayout(topleftlayout);
    leftlayout->addWidget(c1);
      leftlayout->addWidget(c2);
      rightlayout->addWidget(b1);
      rightlayout->addWidget(b2);


      rightlayout->addSpacerItem(new QSpacerItem(10,10, QSizePolicy::Expanding));
      mainlayout->addLayout(leftlayout);
      mainlayout->addLayout(rightlayout);
}
void Dialog2::makeconnexion()
{
    connect(b2, &QPushButton::clicked, this, exit);
}



