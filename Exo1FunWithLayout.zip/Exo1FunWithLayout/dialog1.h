#ifndef DIALOG1_H
#define DIALOG1_H

#include <QWidget>
#include <QPushButton>
#include<QLineEdit>
#include<QLabel.h>

class Dialog1 : public QWidget
{
    Q_OBJECT
public:
    explicit Dialog1(QWidget *parent = nullptr);

protected:
    QLineEdit *edit;
    QLabel *label;
    QPushButton * button;
protected:
    void createWidget();
    void placeWidget();
    void makeConnexions();

};

#endif // DIALOG1_H
