#ifndef DIALOG3_H
#define DIALOG3_H
#include <QPushButton>
#include<QLineEdit>
#include<QTextEdit>
#include <QWidget>
#include<QComboBox>
#include<QDialogButtonBox>


class dialog3 : public QWidget
{
    Q_OBJECT
public:
    explicit dialog3(QWidget *parent = nullptr);

protected:

    QPushButton *b1;
    QPushButton *b2;
    QLineEdit *name;
    QLineEdit *company;
    QLineEdit *phone;
    QLineEdit *email;
    QLineEdit *title;
    QTextEdit *info;
    QComboBox *repro;
    QDialogButtonBox *buttonbox;


protected:
   void createWidgets();
   void placeWidgets();
   void makeconnexion();

};

#endif // DIALOG3_H
