#ifndef DIALOG2_H
#define DIALOG2_H

#include <QWidget>
#include <QPushButton>
#include<QLineEdit>
#include<QLabel.h>
#include<QCheckBox>

class Dialog2 : public QWidget
{
    Q_OBJECT
public:
    explicit Dialog2(QWidget *parent = nullptr);
protected:
    QLabel *l1;
    QCheckBox *c1;
     QCheckBox *c2;
    QPushButton *b1;
    QPushButton *b2;
    QLineEdit *edit;

protected:
   void createWidgets();
   void placeWidgets();
   void makeconnexion();



};

#endif // DIALOG2_H
